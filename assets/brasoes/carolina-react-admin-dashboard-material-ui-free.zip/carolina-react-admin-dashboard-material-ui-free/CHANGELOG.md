# Changelog for Carolina React Admin Dashboard with Material-UI Free

All notable changes for Carolina React Admin Dashboard with Material-UI Free will be documented in this file and online inside the documentation or product presentation page on uifort.com

### This project was released on 15 February 2020 and was last updated on 15 February 2020

----------------------------------------------

## [1.0.0] - Released on 15 February 2020

### Dependencies updates
- nothing as this is the initial release.
### Added
- nothing as this is the initial release.
### Changed
- nothing as this is the initial release.
### Fixed
- nothing as this is the initial release.
----------------------------------------------
